package aircom.model;

/**
 * Attack phase. Attacker selects a launch platform (must be their own
 * ship tile) then selects a target on the opponent's half.
 * Only the attacker's zone is visible during this phase.
 */
public class AttackState implements State {

    private final Player attacker;
    private final Player defender;
    private final GameBoard board;
    private final PlayerInput input;
    private Missile missile;

    public AttackState(Player attacker, Player defender,
                       GameBoard board, PlayerInput input) {
        this.attacker = attacker;
        this.defender = defender;
        this.board = board;
        this.input = input;
    }

    @Override
    public State execute() {
        // Show attacker's zone only
        input.setActiveFlight(attacker.getZone());
        input.setStatusText(attacker.getName() + " — click a ship tile to launch from");

        GridC launchPoint = null;
        while (launchPoint == null) {
            GridC selected = input.getSelection();
            Ship occupant = board.getCell(selected).getOccupant();
            if (occupant != null && attacker.getFleet().contains(occupant)) {
                launchPoint = selected;
            } else {
                input.setStatusText(attacker.getName() + " — invalid! Click one of your ship tiles");
            }
        }

        input.setStatusText(attacker.getName() + " — click a target on the opponent's half");
        GridC target = input.getSelection();

        AttackPath path = AttackCalculator.calculate(launchPoint, target);
        missile = new Missile(launchPoint, target, path);

        System.out.println(attacker.getName() + " launched from " + launchPoint + " targeting " + target);

        return new DefenseState(attacker, defender, board, missile, input);
    }
}