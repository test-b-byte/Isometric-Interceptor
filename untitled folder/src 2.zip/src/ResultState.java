package aircom.model;

/**
 * Resolution phase. flight paths for hits, misses, and intercepts and if game over criteria is met
 * applies damage, notifies observers, checks win condition, and notifies the Observers.
 * swaps roles for next turn.
 * Ships are hidden during resolution — players only see flight paths.
 */
public class ResultState implements State {

    private final Player attacker;
    private final Player defender;
    private final GameBoard board;
    private final Missile missile;
    private final GridC interceptLaunch;
    private final GridC interceptPoint;
    private final PlayerInput input;

    public ResultState(Player attacker, Player defender,
                       GameBoard board, Missile missile,
                       GridC interceptLaunch, GridC interceptPoint,
                       PlayerInput input) {
        this.attacker = attacker;
        this.defender = defender;
        this.board = board;
        this.missile = missile;
        this.interceptLaunch = interceptLaunch;
        this.interceptPoint = interceptPoint;
        this.input = input;
    }

    @Override
    public State execute() {
        input.setActiveFlight(0);
        input.setStatusText("Situation Report...");

        boolean intercepted = false;
        boolean miss = false;
        Ship shipSunk = null;


//check for interception AND note the Grid location of the interception cooridnate to change graphics
        AttackPath interceptPath = AttackCalculator.calculate(interceptLaunch, interceptPoint);

        if (missile.getPath().contains(interceptPoint)) {
            intercepted = true;
            input.showAttackPath(missile.getPath(), true, interceptPoint);
            input.showInterceptPath(interceptPath, true);
            System.out.println("Intercepted!");


            // if not intercepted, checks for hit/ miss, status
        } else {
            Ship targetOccupant = board.getCell(missile.getTarget()).getOccupant();
            input.showAttackPath(missile.getPath(), false, null);
            input.showInterceptPath(interceptPath, false);

            if (targetOccupant != null && defender.getFleet().contains(targetOccupant)) {
                targetOccupant.hit(missile.getTarget());
                board.getCell(missile.getTarget()).setState(Cell.CellState.HIT);
                board.notifyBoardChanged();
                input.showExplosion(missile.getTarget());
                if (targetOccupant.isSunk()) {
                    shipSunk = targetOccupant;
                    System.out.println(targetOccupant.getType() + " sunk!");
                } else {
                    System.out.println("Hit! " + missile.getTarget());
                }
            } else {
                miss = true;
                board.getCell(missile.getTarget()).setState(Cell.CellState.MISS);
                board.notifyBoardChanged();
                System.out.println("Miss.");
            }
        }

        // Build  the script report form the turn after crunching the numbers. Keeps players informed.
        String outcome = intercepted ? "INTERCEPTED" : (miss ? "MISS" : "HIT");
        String sunkLine = shipSunk != null ? "\nSunk: " + shipSunk.getType() : "";
        input.setStatusText(
                "TURN RESULT\n" +
                        "Attack target: (" + missile.getTarget().row() + "," + missile.getTarget().col() + ")\n" +
                        "Intercept point: (" + interceptPoint.row() + "," + interceptPoint.col() + ")\n" +
                        "Outcome: " + outcome + sunkLine + "\n" +
                        "Click to continue."
        );

        //checks to see if the defnding player has any ships left in the fleet.
        System.out.println("##### GAME OVER CHECK ######");
        for (Ship ship : defender.getFleet()) {
            System.out.println(ship.getType() + " isSunk=" + ship.isSunk());
        }
        boolean defenderLost = defender.getFleet().stream().allMatch(Ship::isSunk);
        boolean attackerLost = attacker.getFleet().stream().allMatch(Ship::isSunk);
        boolean gameOver = defenderLost || attackerLost;

        String winnerName = defenderLost ? attacker.getName()
                : attackerLost ? defender.getName()
                  : null;

        attacker.onTurnImpact(missile.getTarget(), intercepted, miss, shipSunk, gameOver, winnerName);
        defender.onTurnImpact(missile.getTarget(), intercepted, miss, shipSunk, gameOver, winnerName);

        if (gameOver) {
            input.setStatusText("GAME OVER — " + winnerName + " wins!\nClick to exit.");
            attacker.onGameOver(winnerName);
            defender.onGameOver(winnerName);
            input.getSelection();
            return new GameOverState();
        }

        input.getSelection();
        return new AttackState(defender, attacker, board, input);
    }
}//CellState.HIT