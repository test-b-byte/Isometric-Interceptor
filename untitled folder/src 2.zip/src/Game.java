package aircom.model;

import aircom.render.GameRender;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Central orchestrator for AirCom.
 * Creates the board, places ships, creates players, starts the state loop.
 * For now ships are hardcoded so we can test the full turn cycle.
 * SetupState will replace hardcoded placement in the final version.
 */
public class Game {

    private final GameBoard board;
    private final Player player1;
    private final Player player2;
    private final GameRender renderer;


    // Hard coded intial set up for time sake.
    public Game() {
        board = new GameBoard();
        renderer = new GameRender(board);
        board.addObserver(renderer);

        //Hard coded the lay out to save time. Ideally would build a game set up phase to allow players
        // to try more strategies but needed things in place to start testing the model and renders as a whole
        Ship p1Carrier = new Ship(ShipType.CARRIER,
                Arrays.asList(
                        new GridC(1, 2),
                        new GridC(2, 2),
                        new GridC(3, 2),
                        new GridC(4, 2),
                        new GridC(5, 2)));

        Ship p1Battleship = new Ship(ShipType.BATTLESHIP,
                Arrays.asList(
                        new GridC(2, 10),
                        new GridC(3, 10),
                        new GridC(4, 10),
                        new GridC(5, 10)));

        Ship p1Cruiser = new Ship(ShipType.CRUISER,
                Arrays.asList(
                        new GridC(8, 15),
                        new GridC(9, 15),
                        new GridC(10, 15)));

        Ship p1Destroyer = new Ship(ShipType.DESTROYER,
                Arrays.asList(
                        new GridC(12, 6),
                        new GridC(13, 6)));

        // --- Player 2 ships --- rows 15-29 (green zone, bottom half)
        // Mirrored spread — different positions to keep game asymmetric

        Ship p2Carrier = new Ship(ShipType.CARRIER,
                Arrays.asList(
                        new GridC(16, 17),
                        new GridC(17, 17),
                        new GridC(18, 17),
                        new GridC(19, 17),
                        new GridC(20, 17)));

        Ship p2Battleship = new Ship(ShipType.BATTLESHIP,
                Arrays.asList(
                        new GridC(18, 8),
                        new GridC(19, 8),
                        new GridC(20, 8),
                        new GridC(21, 8)));

        Ship p2Cruiser = new Ship(ShipType.CRUISER,
                Arrays.asList(
                        new GridC(22, 3),
                        new GridC(23, 3),
                        new GridC(24, 3)));

        Ship p2Destroyer = new Ship(ShipType.DESTROYER,
                Arrays.asList(
                        new GridC(26, 12),
                        new GridC(27, 12)));

        // Place all ships on the board
        board.placeShip(p1Carrier);
        board.placeShip(p1Battleship);
        board.placeShip(p1Cruiser);
        board.placeShip(p1Destroyer);
        board.placeShip(p2Carrier);
        board.placeShip(p2Battleship);
        board.placeShip(p2Cruiser);
        board.placeShip(p2Destroyer);

        // Create players with their fleets
        player1 = new Player("Player 1", 1,
                Arrays.asList(p1Carrier, p1Battleship, p1Cruiser, p1Destroyer));

        player2 = new Player("Player 2", 2,
                Arrays.asList(p2Carrier, p2Battleship, p2Cruiser, p2Destroyer));
    }

    /**
     * Starts the game loop.
     * Runs the state machine until GameOverState is reached.
     * Player 1 attacks first.
     */
    public void start() {
        // Open the window
        JFrame window = new JFrame("AirCom");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.add(renderer);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        // Run state loop on a background thread so Swing can paint
        // "new Thread(...).start()" creates and launches a second thread.
        // The game logic runs there while Swing handles rendering on the
        // main thread.
        new Thread(() -> {
            State current = new AttackState(player1, player2, board, renderer);
            while (!(current instanceof GameOverState)) {
                current = current.execute();
            }
            System.out.println("Game ended.");
        }).start();
    }


    //initatlizing args
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Game().start());
    }
}