package aircom.model;

/**
 * Defense phase. Defender selects an interceptor launch platform
 * (must be their own ship tile) then guesses a point on the
 * attacker's flight path. Only the defender's zone is visible.
 */
public class DefenseState implements State {

    private final Player attacker;
    private final Player defender;
    private final GameBoard board;
    private final Missile missile;
    private final PlayerInput input;

    public DefenseState(Player attacker, Player defender,
                        GameBoard board, Missile missile, PlayerInput input) {
        this.attacker = attacker;
        this.defender = defender;
        this.board = board;
        this.missile = missile;
        this.input = input;
    }

    @Override
    public State execute() {
        // Show defender's zone only
        input.setActiveFlight(defender.getZone());
        input.setStatusText(defender.getName() + " — click a ship tile to launch interceptor from");

        GridC interceptLaunch = null;
        while (interceptLaunch == null) {
            GridC selected = input.getSelection();
            Ship occupant = board.getCell(selected).getOccupant();
            if (occupant != null && defender.getFleet().contains(occupant)) {
                interceptLaunch = selected;
            } else {
                input.setStatusText(defender.getName() + " — invalid! Click one of your ship tiles");
            }
        }

        input.setStatusText(defender.getName() + " — click where you think the missile will pass");
        GridC interceptPoint = input.getSelection();

        System.out.println(defender.getName() + " intercept attempt at " + interceptPoint);

        return new ResultState(attacker, defender, board,
                missile, interceptLaunch, interceptPoint, input);
    }
}