/**
 * THE BIG ONE!!!
 *
 * That which must be displayed is foundeth here. This could actually be broken into smaller components for more simplicity,
 *
 * For now it handles inputs on display, text /HUD display so info isnt limted to the terminal,
 * Graphic/Board tiles changes, colors, etc. I enver did get to the point where I whas downlaoding renders of images
 * so I never really got to the point of refining this portion. I wanted a working skeleton first
 */

package aircom.render;

import aircom.model.GridC;
import aircom.model.GameBoard;
import aircom.model.Cell;
import aircom.model.AttackPath;


//Import J-utilities for creating visual interfaces
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

public class GameRender extends JPanel
        implements KeyListener, aircom.model.PlayerInput, MouseListener, MouseMotionListener, aircom.model.BoardObserver {


    //Board layout
    private static final int COLS     = GameBoard.COLS;
    private static final int ROWS     = GameBoard.ROWS;
    private static final int SPLIT    = GameBoard.ROWS / 2;
    private static final int TILE_W   = 32;
    private static final int TILE_H   = 16;
    private static final int ORIGIN_X = 700;
    private static final int ORIGIN_Y = 200;
    /**
     * Grid colors and tile fills
     */
    private static final Color PLAYER1_FILL        = new Color(42, 90, 160);
    private static final Color PLAYER1_STROKE      = new Color(26, 61, 112);
    private static final Color PLAYER2_FILL        = new Color(42, 128, 96);
    private static final Color PLAYER2_STROKE      = new Color(26, 80, 64);
    private static final Color DIVIDER             = new Color(255, 215, 0);
    private static final Color CURSOR_FILL         = new Color(255, 255, 100);
    private static final Color CURSOR_STROKE       = new Color(200, 200, 0);
    private static final Color SHIP_FILL           = new Color(180, 140, 80);
    private static final Color SHIP_STROKE         = new Color(120, 90, 40);
    private static final Color HIT_FILL            = new Color(180, 40, 40);
    private static final Color HIT_STROKE          = new Color(120, 20, 20);
    private static final Color MISS_FILL           = new Color(100, 100, 110);
    private static final Color MISS_STROKE         = new Color(70, 70, 70);
    private static final Color ATTACK_PATH_FILL    = new Color(255, 165, 0);
    private static final Color ATTACK_PATH_STROKE  = new Color(200, 120, 0);
    private static final Color INTERCEPT_PATH_FILL   = new Color(180, 80, 255);
    private static final Color INTERCEPT_PATH_STROKE = new Color(120, 40, 180);

    // Explosion flicker colors, cheap animation, I just cycle some colors and expand the zone with the white, red, yellow cycling
    private static final Color[] EXPLOSION_COLORS = {
            new Color(255, 255, 255),
            new Color(255, 60, 60),
            new Color(255, 220, 0)
    };

    private final IsoRig isoRig;
    private final GameBoard board;
    private volatile GridC cursor;
    private volatile GridC selection;

    // Attack path
    private volatile AttackPath lastAttackPath  = null;
    private volatile boolean attackPathVisible  = false;
    private volatile int visibleAttackCount     = 0;

    // Intercept path
    private volatile AttackPath lastInterceptPath   = null;
    private volatile boolean interceptPathVisible   = false;
    private volatile int visibleInterceptCount      = 0;

    // Explosion at intercept point
    private volatile List<GridC> explosionTiles = new ArrayList<>();
    private volatile boolean explosionVisible   = false;
    private volatile int explosionColorIndex    = 0;

    private volatile int activeFlight  = 1;
    private volatile String statusText = "Welcome to AirCom";

    // Multi-line status support
    private volatile String[] statusLines = {"Welcome to AirCom"};



    // initialize the display with all the components for input etc.
    public GameRender(GameBoard board, int playerZone) {
        super();
        this.board = board;
        this.activeFlight = playerZone;
        this.isoRig = new IsoRig(TILE_W, TILE_H);
        this.cursor = new GridC(0, 0);
        this.selection = null;
        setPreferredSize(new Dimension(1200, 900));
        setBackground(new Color(20, 20, 30));
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        setFocusable(true);
    }
    @Override
    //HUD (this is used as a basic means of keeping players informed
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D canvas = (Graphics2D) g;
        canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                drawTile(canvas, row, col);
            }
        }
        drawDivider(canvas);
        drawHUD(canvas);
    }

    private void drawTile(Graphics2D canvas, int row, int col) {
        int tCenterX = ORIGIN_X + isoRig.pixelX(row, col);
        int tCenterY = ORIGIN_Y + isoRig.pixelY(row, col);

        Polygon diamond = new Polygon();
        diamond.addPoint(tCenterX,            tCenterY);
        diamond.addPoint(tCenterX + TILE_W/2, tCenterY + TILE_H/2);
        diamond.addPoint(tCenterX,            tCenterY + TILE_H);
        diamond.addPoint(tCenterX - TILE_W/2, tCenterY + TILE_H/2);

        Cell.CellState state = board.getCell(new GridC(row, col)).getState();

        // Only show ships/hits/misses on the active player's zone.
        // activeFlight 0 = result phase, hide all ships.
        boolean isActiveZone = (activeFlight == 1 && row < SPLIT)
                || (activeFlight == 2 && row >= SPLIT);
        boolean isOpponentZone = (activeFlight == 1 && row >= SPLIT)
                || (activeFlight == 2 && row < SPLIT);

        boolean isHit      = isOpponentZone && state == Cell.CellState.HIT;
        boolean isMiss     = isOpponentZone && state == Cell.CellState.MISS;
        boolean isOccupied = isActiveZone   && state == Cell.CellState.OCCUPIED;
        boolean isCursor   = cursor != null
                && cursor.row() == row && cursor.col() == col;

        // Attack path check — how many tiles revealed so far
        int attackIndex = (lastAttackPath != null)
                ? lastAttackPath.getPath().indexOf(new GridC(row, col)) : -1;
        boolean isAttackPath = attackPathVisible
                && attackIndex >= 0 && attackIndex < visibleAttackCount;

        // Intercept path check
        int interceptIndex = (lastInterceptPath != null)
                ? lastInterceptPath.getPath().indexOf(new GridC(row, col)) : -1;
        boolean isInterceptPath = interceptPathVisible
                && interceptIndex >= 0 && interceptIndex < visibleInterceptCount;

        // Explosion check
        boolean isExplosion = explosionVisible
                && explosionTiles.contains(new GridC(row, col));

        // Determine colors — priority order:
        // explosion > cursor > intercept path > attack path > hit > miss > ship > ocean
        Color fillColor;
        Color strokeColor;

        if (isExplosion) {
            fillColor   = EXPLOSION_COLORS[explosionColorIndex % 3];
            strokeColor = fillColor.darker();
        } else if (isCursor) {
            fillColor   = CURSOR_FILL;
            strokeColor = CURSOR_STROKE;
        } else if (isInterceptPath) {
            fillColor   = INTERCEPT_PATH_FILL;
            strokeColor = INTERCEPT_PATH_STROKE;
        } else if (isAttackPath) {
            fillColor   = ATTACK_PATH_FILL;
            strokeColor = ATTACK_PATH_STROKE;
        } else if (isHit) {
            fillColor   = HIT_FILL;
            strokeColor = HIT_STROKE;
        } else if (isMiss) {
            fillColor   = MISS_FILL;
            strokeColor = MISS_STROKE;
        } else if (isOccupied) {
            fillColor   = SHIP_FILL;
            strokeColor = SHIP_STROKE;
        } else {
            fillColor   = row < SPLIT ? PLAYER1_FILL : PLAYER2_FILL;
            strokeColor = row < SPLIT ? PLAYER1_STROKE : PLAYER2_STROKE;
        }

        canvas.setColor(fillColor);
        canvas.fillPolygon(diamond);
        canvas.setColor(strokeColor);
        canvas.drawPolygon(diamond);
    }

    private void drawDivider(Graphics2D canvas) {
        int startX = ORIGIN_X + isoRig.pixelX(SPLIT, 0);
        int startY = ORIGIN_Y + isoRig.pixelY(SPLIT, 0);
        int endX   = ORIGIN_X + isoRig.pixelX(SPLIT, COLS);
        int endY   = ORIGIN_Y + isoRig.pixelY(SPLIT, COLS);
        canvas.setColor(DIVIDER);
        canvas.drawLine(startX, startY, endX, endY);
    }

    private void drawHUD(Graphics2D canvas) {
        // Multi-line status text
        canvas.setFont(new Font("Monospaced", Font.BOLD, 16));
        int y = 35;
        for (String line : statusLines) {
            // Color code outcome lines
            if (line.contains("INTERCEPTED")) canvas.setColor(new Color(180, 80, 255));
            else if (line.contains("HIT"))    canvas.setColor(new Color(255, 80, 80));
            else if (line.contains("MISS"))   canvas.setColor(new Color(200, 200, 200));
            else if (line.contains("SUNK"))   canvas.setColor(new Color(255, 60, 60));
            else if (line.contains("GAME OVER")) canvas.setColor(new Color(255, 215, 0));
            else                              canvas.setColor(Color.WHITE);
            canvas.drawString(line, 20, y);
            y += 22;
        }

        // Zone labels — below status
        y = Math.max(y + 10, 120);
        canvas.setFont(new Font("Monospaced", Font.BOLD, 14));
        canvas.setColor(new Color(100, 160, 255));
        canvas.drawString("▲ PLAYER 1", 20, y);
        canvas.setColor(new Color(100, 220, 140));
        canvas.drawString("▼ PLAYER 2", 20, y + 20);

        // Cursor position
        if (cursor != null) {
            canvas.setFont(new Font("Monospaced", Font.PLAIN, 12));
            canvas.setColor(new Color(150, 150, 150));
            canvas.drawString("cursor: (" + cursor.row() + "," + cursor.col() + ")",
                    20, y + 45);
        }

        // Path legend
        if (attackPathVisible || interceptPathVisible) {
            canvas.setFont(new Font("Monospaced", Font.BOLD, 12));
            canvas.setColor(ATTACK_PATH_FILL);
            canvas.drawString("■ Attack", 20, y + 65);
            canvas.setColor(INTERCEPT_PATH_FILL);
            canvas.drawString("■ Intercept", 20, y + 82);
        }
    }

    /**
     * Animates attack path orange tile by tile.
     * If intercepted=true, stops at intercept point and triggers explosion.
     */
    @Override
    public void showAttackPath(AttackPath path, boolean intercepted, GridC interceptPoint) {
        lastAttackPath = path;
        visibleAttackCount = 0;
        attackPathVisible = true;
        repaint();

        final int totalTiles = intercepted
                ? findInterceptTile(path, interceptPoint)
                : path.getPath().size();

        Timer animTimer = new Timer(150, null);
        animTimer.addActionListener(evt -> {
            visibleAttackCount++;
            repaint();
            if (visibleAttackCount >= totalTiles) {
                animTimer.stop();
                if (intercepted) {
                    triggerExplosion(path.getPath().get(totalTiles - 1));
                }
                Timer clearTimer = new Timer(2500, e -> {
                    attackPathVisible = false;
                    lastAttackPath = null;
                    visibleAttackCount = 0;
                    repaint();
                });
                clearTimer.setRepeats(false);
                clearTimer.start();
            }
        });
        animTimer.setRepeats(true);
        animTimer.start();
    }

    /**
     * Finds how many tiles of the attack path to show before intercept.
     * Returns path size if intercept not on path.
     */
    private int findInterceptTile(AttackPath path, GridC interceptPoint) {
        // Find the index of the intercept point on the path
        // Stop missile never reaches beyond this tile
        int index = path.getPath().indexOf(interceptPoint);
        return index >= 0 ? index + 1 : path.getPath().size();
    }

    /**
     * Triggers white→red→yellow flickering explosion at a tile
     * and its 4 adjacent neighbors for 1.5 seconds.
     */
    private void triggerExplosion(GridC center) {
        explosionTiles = new ArrayList<>();
        explosionTiles.add(center);
        //  clamped explosion splash effeect to board bounds
        if (center.row() > 0)        explosionTiles.add(new GridC(center.row()-1, center.col()));
        if (center.row() < ROWS-1)   explosionTiles.add(new GridC(center.row()+1, center.col()));
        if (center.col() > 0)        explosionTiles.add(new GridC(center.row(), center.col()-1));
        if (center.col() < COLS-1)   explosionTiles.add(new GridC(center.row(), center.col()+1));

        explosionColorIndex = 0;
        explosionVisible = true;
        repaint();

        // Flicker every 200ms, try and create a "dynamic" look with  color cycles white→red→yellow
        Timer flickerTimer = new Timer(200, null);
        final int[] ticks = {0};
        flickerTimer.addActionListener(evt -> {
            ticks[0]++;
            explosionColorIndex = ticks[0] % 3;
            repaint();
            if (ticks[0] >= 8) { // ~1.6 seconds
                flickerTimer.stop();
                explosionVisible = false;
                explosionTiles.clear();
                repaint();
            }
        });
        flickerTimer.setRepeats(true);
        flickerTimer.start();
    }

    /**
     * Animates intercept path purple tile by tile.
     * If successful=true, triggers explosion at end point.
     */
    @Override
    public void showInterceptPath(AttackPath path, boolean successful) {
        lastInterceptPath = path;
        visibleInterceptCount = 0;
        interceptPathVisible = true;
        repaint();

        final int totalTiles = path.getPath().size();
        Timer animTimer = new Timer(150, null);
        animTimer.addActionListener(evt -> {
            visibleInterceptCount++;
            repaint();
            if (visibleInterceptCount >= totalTiles) {
                animTimer.stop();
                if (successful) {
                    triggerExplosion(path.getPath().get(totalTiles - 1));
                }
                Timer clearTimer = new Timer(2500, e -> {
                    interceptPathVisible = false;
                    lastInterceptPath = null;
                    visibleInterceptCount = 0;
                    repaint();
                });
                clearTimer.setRepeats(false);
                clearTimer.start();
            }
        });
        animTimer.setRepeats(true);
        animTimer.start();
    }
    @Override
    public void showExplosion(GridC center) {
        SwingUtilities.invokeLater(() -> triggerExplosion(center));
    }

    @Override
    public void setActiveFlight(int zone) {
        this.activeFlight = zone;
        SwingUtilities.invokeLater(this::repaint);
    }

    @Override
    public void setStatusText(String text) {
        this.statusText = text;
        this.statusLines = text.split("\n");
        SwingUtilities.invokeLater(this::repaint);
    }

    @Override
    public void onBoardChanged() {
        SwingUtilities.invokeLater(this::repaint);
    }

    /**
     *Contorller interface, like keyboard and mouse movement etc.
     */


    @Override
    public void keyPressed(KeyEvent e) {
        int row = cursor.row();
        int col = cursor.col();
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP    -> row = Math.max(0, row - 1);
            case KeyEvent.VK_DOWN  -> row = Math.min(ROWS - 1, row + 1);
            case KeyEvent.VK_LEFT  -> col = Math.max(0, col - 1);
            case KeyEvent.VK_RIGHT -> col = Math.min(COLS - 1, col + 1);
            case KeyEvent.VK_ENTER -> {
                synchronized (this) {
                    selection = cursor;
                    notify();
                }
            }
        }
        cursor = new GridC(row, col);
        repaint();
    }

    @Override public void keyReleased(KeyEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}

    @Override
    public void mouseClicked(MouseEvent e) {
        synchronized (this) {
            selection = cursor;
            notify();
        }
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {
        int screenX = e.getX() - ORIGIN_X;
        int screenY = e.getY() - ORIGIN_Y;
        int row = isoRig.gridRow(screenX, screenY);
        int col = isoRig.gridCol(screenX, screenY);
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) return;
        cursor = new GridC(row, col);
        repaint();
    }

    @Override public void mouseDragged(MouseEvent e) {}

    @Override
    public synchronized GridC getSelection() {
        selection = null;
        try {
            while (selection == null) {
                wait();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return selection;
    }
}