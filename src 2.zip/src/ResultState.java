package aircom.model;

import aircom.render.GameRender;

/**
 * Resolution phase. Shows animations on both windows simultaneously.
 * Both players see the flight paths during resolution.
 * Roles swap for next turn — renderers swap too.
 */
public class ResultState implements State {

    private final Player attacker;
    private final Player defender;
    private final GameBoard board;
    private final Missile missile;
    private final GridC interceptLaunch;
    private final GridC interceptPoint;
    private final GameRender attackerRenderer;
    private final GameRender defenderRenderer;

    public ResultState(Player attacker, Player defender,
                       GameBoard board, Missile missile,
                       GridC interceptLaunch, GridC interceptPoint,
                       GameRender attackerRenderer,
                       GameRender defenderRenderer) {
        this.attacker = attacker;
        this.defender = defender;
        this.board = board;
        this.missile = missile;
        this.interceptLaunch = interceptLaunch;
        this.interceptPoint = interceptPoint;
        this.attackerRenderer = attackerRenderer;
        this.defenderRenderer = defenderRenderer;
    }

    @Override
    public State execute() {
        attackerRenderer.setStatusText("Resolving turn...");
        defenderRenderer.setStatusText("Resolving turn...");

        boolean intercepted = false;
        boolean miss = false;
        Ship shipSunk = null;

        AttackPath interceptPath = AttackCalculator.calculate(interceptLaunch, interceptPoint);

        if (missile.getPath().contains(interceptPoint)) {
            intercepted = true;
            // Show animations on both windows
            attackerRenderer.showAttackPath(missile.getPath(), true, interceptPoint);
            defenderRenderer.showAttackPath(missile.getPath(), true, interceptPoint);
            attackerRenderer.showInterceptPath(interceptPath, true);
            defenderRenderer.showInterceptPath(interceptPath, true);
            System.out.println("Intercepted!");

        } else {
            attackerRenderer.showAttackPath(missile.getPath(), false, null);
            defenderRenderer.showAttackPath(missile.getPath(), false, null);
            attackerRenderer.showInterceptPath(interceptPath, false);
            defenderRenderer.showInterceptPath(interceptPath, false);

            Ship targetOccupant = board.getCell(missile.getTarget()).getOccupant();
            if (targetOccupant != null && defender.getFleet().contains(targetOccupant)) {
                targetOccupant.hit(missile.getTarget());
                board.getCell(missile.getTarget()).setState(Cell.CellState.HIT);
                board.notifyBoardChanged();
                attackerRenderer.showExplosion(missile.getTarget());
                defenderRenderer.showExplosion(missile.getTarget());
                if (targetOccupant.isSunk()) {
                    shipSunk = targetOccupant;
                    System.out.println(targetOccupant.getType() + " sunk!");
                }
            } else {
                miss = true;
                board.getCell(missile.getTarget()).setState(Cell.CellState.MISS);
                board.notifyBoardChanged();
                System.out.println("Miss.");
            }
        }

        String outcome = intercepted ? "INTERCEPTED" : (miss ? "MISS" : "HIT");
        String sunkLine = shipSunk != null ? "\nSunk: " + shipSunk.getType() : "";
        String report = "TURN RESULT\n"
                + "Target: (" + missile.getTarget().row() + "," + missile.getTarget().col() + ")\n"
                + "Intercept: (" + interceptPoint.row() + "," + interceptPoint.col() + ")\n"
                + "Outcome: " + outcome + sunkLine + "\nClick to continue.";

        attackerRenderer.setStatusText(report);
        defenderRenderer.setStatusText(report);

        boolean defenderLost = defender.getFleet().stream().allMatch(Ship::isSunk);
        boolean attackerLost = attacker.getFleet().stream().allMatch(Ship::isSunk);
        boolean gameOver = defenderLost || attackerLost;
        String winnerName = defenderLost ? attacker.getName()
                : attackerLost ? defender.getName() : null;

        attacker.onTurnImpact(missile.getTarget(), intercepted, miss, shipSunk, gameOver, winnerName);
        defender.onTurnImpact(missile.getTarget(), intercepted, miss, shipSunk, gameOver, winnerName);

        if (gameOver) {
            attackerRenderer.setStatusText("GAME OVER — " + winnerName + " wins!\nClick to exit.");
            defenderRenderer.setStatusText("GAME OVER — " + winnerName + " wins!\nClick to exit.");
            attacker.onGameOver(winnerName);
            defender.onGameOver(winnerName);
            attackerRenderer.getSelection();
            return new GameOverState();
        }

        // Wait for attacker to click continue on their window
        attackerRenderer.getSelection();

        // Swap roles — renderers swap too
        // Old attacker's renderer becomes new defender's renderer and vice versa
        return new AttackState(defender, attacker, board,
                defenderRenderer, attackerRenderer);
    }
}